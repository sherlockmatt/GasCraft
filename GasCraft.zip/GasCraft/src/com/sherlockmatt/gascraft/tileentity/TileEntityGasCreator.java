package com.sherlockmatt.gascraft.tileentity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.google.common.collect.Ordering;
import com.sherlockmatt.gascraft.GasCraft;
import com.sherlockmatt.gascraft.util.MapUtil;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class TileEntityGasCreator extends TileEntity{
	private boolean canWork = false;
	private Block block;
	private World world;
	Map<Integer[], Float> blockMap = new HashMap<Integer[], Float>();
	private int maxWork;
	private int work;
	private boolean startedWork = false;
	
	public TileEntityGasCreator(){
		this.maxWork = 1;
	}
	
	@Override
	public void func_145845_h() {
		if (this.field_145850_b != null && !this.field_145850_b.isRemote && this.field_145850_b.getTotalWorldTime() % 20L == 0L)
        {
			this.block = this.func_145838_q();
			this.world = func_145831_w();
			if (this.startedWork == false) {
				Integer[] blockXYZ = {this.field_145851_c, this.field_145848_d - 1, this.field_145849_e};
				this.blockMap.put(blockXYZ, this.evaluateBlock(this.field_145851_c, this.field_145848_d - 1, this.field_145849_e));
				this.blockMap = MapUtil.sortByValue( this.blockMap );
				this.startedWork = true;
			}
			if (this.canWork) {
				this.canWork = checkMultiBlock();
				this.work = 0;
				for(Entry<Integer[], Float> entry : this.blockMap.entrySet())
				{
					if (world.rand.nextBoolean()) {
						this.work++;
						Integer[] xyz = entry.getKey();
						addMiningGas(xyz[0],xyz[1],xyz[2]);
						//this.world.func_147465_d(xyz[0], xyz[1], xyz[2], GameRegistry.findBlock(GasCraft.MODID, "MiningGas"), 0, 2);
						this.blockMap.remove(xyz);
					}
					if (this.work >= this.maxWork) break;
				}
				//this.world.func_147465_d(this.field_145851_c, this.field_145848_d - 1, this.field_145849_e, GameRegistry.findBlock(GasCraft.MODID, "MiningGas"), 0, 2);
				System.out.println(checkMultiBlock() ? "Work Ticking." : "Stopped Work");
			} else {
				if (checkMultiBlock()){
					//this.world.func_147465_d(this.field_145851_c, this.field_145848_d - 1, this.field_145849_e, GameRegistry.findBlock(GasCraft.MODID, "MiningGas"), 0, 2);
					startWork();
				}
			}
        }
	}
	
	private boolean checkMultiBlock(){
		this.block = this.func_145838_q();
		
		this.world = func_145831_w();
		if(this.world.func_147439_a(this.field_145851_c, this.field_145848_d, this.field_145849_e) == this.block)
		{
			if(this.world.func_147439_a(this.field_145851_c, this.field_145848_d + 1, this.field_145849_e) == GameRegistry.findBlock(GasCraft.MODID, "GasDistributor"))
			{
				if(this.world.func_147439_a(this.field_145851_c + 1, this.field_145848_d, this.field_145849_e) == GameRegistry.findBlock(GasCraft.MODID, "GasAmplifier") && world.func_147439_a(this.field_145851_c - 1, this.field_145848_d, this.field_145849_e) == GameRegistry.findBlock(GasCraft.MODID, "GasAmplifier") && world.func_147439_a(this.field_145851_c, this.field_145848_d, this.field_145849_e + 1) == GameRegistry.findBlock(GasCraft.MODID, "GasAmplifier") && world.func_147439_a(this.field_145851_c, this.field_145848_d, this.field_145849_e - 1) == GameRegistry.findBlock(GasCraft.MODID, "GasAmplifier"))
				{
					return true;
				}
			}
		}
		return false;
	}
	
	private void addMiningGas(int par1, int par2, int par3) {
		addMiningGas(par1, par2, par3, true);
	}
	
	private void addMiningGas(int par1, int par2, int par3, boolean par4) {
		world = func_145831_w();
		block = func_145838_q();
		world.func_147465_d(par1, par2, par3, GameRegistry.findBlock(GasCraft.MODID, "MiningGas"), 0, 2);
		if (!par4) return;
		//Check directions
		int o1,o2,o3;
		for (int i=0; i<6; i++) {
			switch (i) {
				case 0:
					o1 = 1;
					o2 = 0;
					o3 = 0;
					break;
				case 1:
					o1 = -1;
					o2 = 0;
					o3 = 0;
					break;
				case 2:
					o1 = 0;
					o2 = 1;
					o3 = 0;
					break;
				case 3:
					o1 = 0;
					o2 = -1;
					o3 = 0;
					break;
				case 4:
					o1 = 0;
					o2 = 0;
					o3 = 1;
					break;
				case 5:
					o1 = 1;
					o2 = 0;
					o3 = -1;
					break;
				default:
					o1 = 0;
					o2 = 0;
					o3 = 0;
					break;	
			}
			if (world.func_147439_a(par1+o1, par2+o2, par3+o3) == Blocks.air & !(world.func_147439_a(par1+o1, par2+o2, par3+o3) == GameRegistry.findBlock(GasCraft.MODID, "MiningGas"))) {
				Integer[] blockXYZ = {par1+o1, par2+o2, par3+o3};
				if (!this.blockMap.containsKey(blockXYZ)) {
					this.blockMap.put(blockXYZ, this.evaluateBlock(par1+o1, par2+o2, par3+o3));
					this.blockMap = MapUtil.sortByValue( this.blockMap );
				}
			}
		}
	}
	
	private float evaluateBlock(int par1, int par2, int par3) {
		int dx = Math.abs(this.field_145851_c-par1);
		int dy = this.field_145848_d-par2-3;
		int dz = Math.abs(this.field_145849_e-par3);
		float dyz = (float) Math.sqrt(dx*dx + dz*dz + (dy*dy)/2);
		if (dyz >= 0){
			return dyz;
		} else {
			return 999999;
		}
	}
	public void startWork(){
		if (this.canWork != true)
		{
			System.out.println("Started work");
			this.canWork = true;
			//set hashmap
		}
	}
}
